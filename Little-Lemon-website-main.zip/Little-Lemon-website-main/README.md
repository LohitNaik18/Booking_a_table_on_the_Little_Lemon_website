## Coursera - Front-End Developer Capstone Project

### Booking a table on the Little Lemon website

#### Review criteria

In the web browser: Does the Little Lemon web app match the UI/UX from the Figma mockup and wireframe?

In the web browser: Does the Little Lemon web app match the UI/UX from the Figma mockup and wireframe?

In the web browser: Using the web browser developer tools, does the web app layout correctly for both mobile and desktop devices?

In the web browser: Using the web browser developer tools, does the web app layout correctly for both mobile and desktop devices?

In visual studio code: Is the BookingForm component a child component?

In visual studio code: Is the state of the available times managed from the parent component of BookingForm?

In visual studio code: Does the booking form implement client-side validation?

In visual studio code: Are there unit tests added for form component and validation?

In visual studio code: Do the unit tests pass successfully?
